package programação;

import java.util.Scanner;

public class programação07 {
    
    public static void main(String [] Args){
        
        Scanner input = new Scanner (System.in);
        
        
        double salario;
        int porcentagem = 7;
        int cem = 100;
        double reajuste;
        reajuste = cem / porcentagem;
        double result;
      
                    
        System.out.println("Digite seu salario:");
                salario  = input.nextDouble();
                  result = reajuste * salario;
                System.out.println("O valor do salario com o reajuste realizado foi: R$" + result);
    }
}