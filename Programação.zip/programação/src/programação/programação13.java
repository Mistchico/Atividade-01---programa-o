package programação;

import java.util.Scanner;

public class programação13 {
    
    public static void main( String Args []) {
        
        Scanner input = new Scanner(System.in);
        
 double num;
        double num2;
        int num3;
        double liquido;
        
                System.out.println("Digite o valor da hora de trabalho:");
                num = input.nextDouble();
                System.out.println("Digite suas horas trabalhadas no mes:");
                num2 = input.nextDouble();
                System.out.println("Digite o desconto INSS:");
                num3 = input.nextInt();
                liquido = num2 - num3;
                        System.out.println("O salario liquido será: R$" + liquido); 
        
        
    }
}