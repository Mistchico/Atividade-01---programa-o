package programção;

import static java.lang.System.out;
import java.util.Scanner;

public class programação12 {
    
    public static void main(String [] Args) {
        Scanner input = new Scanner(System.in);
        int num;
        int antecessor;
        int sucessor;
        System.out.println("Digite um numero");
        num = input.nextInt();
        antecessor = num -1;
        sucessor = num +1;
  
                System.out.println("O antecessor de " + num + "é: " + antecessor);
                System.out.println("O sucessor de " + num + "é: " + sucessor);
    }
}