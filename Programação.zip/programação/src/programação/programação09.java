package programação;

import java.util.Scanner;

public class programação09 {
    
    public static void main(String [] Args){
        
        Scanner input = new Scanner(System.in);
        
        double PI;
        PI = 3.1416;
        double area;
        double raio;
        
        System.out.println("digite o valor de raio do circulo:");
        raio = input.nextDouble();
        
        area = PI * raio;
        
        System.out.println("O valor da area é: " + area);
        
    }
}