package programação;

import java.util.Scanner;

public class programação11{
    
    public static void main(String [] Args){
        
        Scanner input = new Scanner(System.in);
        
        double media;
        double media2;
        double media3;
        double mediaAluno;
        
        System.out.println("Digite a sua nota do primeiro bimestre:");
        media = input.nextDouble();
        System.out.println("Digite a sua nota do segundo bimestre:");
        media2 = input.nextDouble();
        System.out.println("Digite a sua nota do terceiro bimestre:");
        media3 = input.nextDouble();
        mediaAluno = (media + media2 + media3) / 3;
        System.out.println("A media final do aluno foi: " + mediaAluno);
        
        
      
    }
}