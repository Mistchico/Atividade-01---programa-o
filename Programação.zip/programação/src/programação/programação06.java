package programação;

import java.util.Scanner;

public class programação06 {
    
    public static void main(String [] Args) {
        
        Scanner input = new Scanner (System.in);
        
        int idade;
        int vivencia;
        vivencia = 12;
        int dias;
        
        System.out.println("Quantos anos Chico tinha?");
        idade = input.nextInt();
                dias = idade * vivencia;
        System.out.println("Chico viveu " + dias + " dias antes de seu falecimento");
    }
}