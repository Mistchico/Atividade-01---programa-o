package programação;

public class programação02 {
    
   public static void  main(String [] args){
       int x,y,div;
               x = 20;
                       y = 10;
                               div = x % y;
                               
       
       System.out.println("o resultado da divisao entre os numeros é: " + div);      
    
    
}
}