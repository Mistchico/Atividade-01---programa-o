package programação;

import java.util.Scanner;

public class programação03 {
    
    public static void main(String [] args){
        
        Scanner input = new Scanner(System.in);
           String nome;
        
        System.out.println("Escreva seu nome:");
        
nome = input.nextLine();
System.out.println("seu nome é:" + nome);
    }
    
}