package programação;
        
import java.util.Scanner;

public class programação05 {
    
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
       int num1;
        double num2 = 4.95;
        double multi;
        
        System.out.println("Chico comprou a seguinte quantidade de dados:");
        num1 = input.nextInt();
System.out.println("\nSe a atual cotação do dólar é: " + num2);
    
    multi = num1 * num2;
System.out.println("\nNa atual conversão, o total gastos será de: R$" + multi);

    }
    
    
}