package programação;
        
import java.util.Scanner;

public class programação04 {
    
    public static void main( String [] args){
        Scanner input = new Scanner(System.in);
        
        String nome;
        String endereço;
                String telefone;
                        
                        System.out.println("Escreva seu nome:");
                        nome = input.nextLine();
                        
                        System.out.println("o nome dele é:" + nome);
                        System.out.println("\nEscreva seu endereço");
                        endereço = input.nextLine();
                        System.out.println("\nSeu endereço é:" + endereço);
                        System.out.println("\nEscreva seu telefone:");
                        telefone = input.nextLine();
                        System.out.println("\nSeu whatsaap é:" +telefone);
    }
}