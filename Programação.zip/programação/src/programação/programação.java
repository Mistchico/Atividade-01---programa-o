package programação;
        
public class programação {
    
    public static void  main(String[] args){
        
        
      int x,y,soma;
      x = 20;
      y = 50;
      soma = x + y;
      
      
        System.out.println("Digite o primeiro numero: " + x + " \nDigite o segundo numero: " + y + "\nO resultado sera: " + soma);
    }
}
