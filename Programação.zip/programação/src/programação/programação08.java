package programação;
        
import java.util.Scanner;

public class programação08 {
    
    public static void main(String [] Args){
        
        Scanner input = new Scanner(System.in);
        
        int metro;
                int cm;
                cm = 100;
                int result;
                
                System.out.println("Digite a quantidade de metros desse comodo:");
                        metro = input.nextInt();
                        result = metro * cm;
                        System.out.println("Convertendo essa quantidade para centimetros teriamos: " + result + "CM");
        
        
    }
}